#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
The framework of traing process
~~~~~
Before python train.py, please ensure running the "python -m visdom.server -port=xxx" where xxx is the port assign in options
"""

import random
import torch
import torch.nn as nn
import time
import numpy as np
import hues
import os
from data import get_dataloader
from model import create_model
from options.train_options import TrainOptions
from utils.visualizer import Visualizer

def setup_seed(seed):
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    np.random.seed(seed)
    random.seed(seed)
    # torch.backends.cudnn.deterministic =True
setup_seed(1)

if __name__ == "__main__":

    train_opt = TrainOptions().parse()
    train_dataloader = get_dataloader(train_opt, isTrain=True)
    dataset_size = len(train_dataloader)
    train_model = create_model(train_opt, train_dataloader.hsi_channels,
                               train_dataloader.msi_channels,
                               train_dataloader.sp_matrix,
                               train_dataloader.sp_range)

    train_model.setup(train_opt)
    visualizer = Visualizer(train_opt, train_dataloader.sp_matrix)

    test_dataloader = get_dataloader(train_opt, isTrain=False)

    total_steps = 0
    iter_count = 0  # 迭代计数器
    batch_start_time = time.time()  # 用于记录1000次的起始时间

    # 设置文件路径与 opt.txt 一致
    expr_dir = os.path.join(train_opt.checkpoints_dir, train_opt.name)
    os.makedirs(expr_dir, exist_ok=True)
    runtime_log_path = os.path.join(expr_dir, 'runtime_log.txt')

    # 打开或创建一个txt文件用于保存运行时长
    with open(runtime_log_path, "a") as f:

        for epoch in range(train_opt.epoch_count, train_opt.niter + train_opt.niter_decay + 1):

            epoch_start_time = time.time()
            epoch_iter = 0

            train_psnr_list = []
            for i, data in enumerate(train_dataloader):

                iter_start_time = time.time()
                total_steps += train_opt.batchsize
                epoch_iter += train_opt.batchsize
                iter_count += 1  # 更新迭代计数

                visualizer.reset()

                train_model.set_input(data, True)
                train_model.optimize_joint_parameters(epoch)

                hues.info("[{}/{} in {}/{}]".format(i, dataset_size // train_opt.batchsize,
                                                    epoch, train_opt.niter + train_opt.niter_decay))

                train_psnr = train_model.cal_psnr()
                train_psnr_list.append(train_psnr)

                if iter_count % 1000 == 0:
                    # 保存每1000次迭代的总运行时长
                    elapsed_time = time.time() - batch_start_time
                    f.write(f"Iteration {iter_count}: Total elapsed time for last 1000 iterations: {elapsed_time:.4f} seconds\n")
                    f.flush()  # 确保每次写入后立即保存
                    batch_start_time = time.time()  # 重新开始计时

                if epoch % train_opt.print_freq == 0:
                    losses = train_model.get_current_losses()
                    t = (time.time() - iter_start_time) / train_opt.batchsize
                    visualizer.print_current_losses(epoch, epoch_iter, losses, t)
                    if train_opt.display_id > 0:
                        visualizer.plot_current_losses(epoch, float(epoch_iter) / dataset_size, train_opt, losses)
                        visualizer.display_current_results(train_model.get_current_visuals(),
                                                           train_model.get_image_name(), epoch, True,
                                                           win_id=[1])

                        visualizer.plot_spectral_lines(train_model.get_current_visuals(), train_model.get_image_name(),
                                                       visual_corresponding_name=train_model.get_visual_corresponding_name(),
                                                       win_id=[2,3])
                        visualizer.plot_psnr_sam(train_model.get_current_visuals(), train_model.get_image_name(),
                                                 epoch, float(epoch_iter) / dataset_size,
                                                 train_model.get_visual_corresponding_name())

                        visualizer.plot_lr(train_model.get_LR(), epoch)

            print('End of epoch %d / %d \t Time Taken: %d sec' % (epoch, train_opt.niter + train_opt.niter_decay, time.time() - epoch_start_time))

            # train_model.update_learning_rate(np.mean(np.array(train_psnr_list)[:]))
            train_model.update_learning_rate()

        train_model.savePSFweight()
        # train_model.save_networks(train_opt.niter + train_opt.niter_decay)
        train_model.saveAbundance()


