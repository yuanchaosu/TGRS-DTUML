import math

import torch
import torch.nn as nn
from torch.nn import init
import functools
from torch.optim import lr_scheduler
import torch.nn.functional as F
from .attention import NonLocalAttention
from .attention import  cSEBlock
from .attention import CBAM
from .attention import  CALayer
from .attention import SEAttention
from .attention import SKAttention
from .attention import AttentionFreeTransformer


def get_scheduler(optimizer, opt):
    if opt.lr_policy == 'lambda':
        def lambda_rule(epoch):
            lr_l = 1.0 - max(0, epoch + 1 + opt.epoch_count - opt.niter) / float(opt.niter_decay + 1)
            return lr_l

        scheduler = lr_scheduler.LambdaLR(optimizer, lr_lambda=lambda_rule)
    elif opt.lr_policy == 'step':
        scheduler = lr_scheduler.StepLR(optimizer, step_size=opt.lr_decay_iters, gamma=opt.lr_decay_gamma)
    elif opt.lr_policy == 'plateau':
        scheduler = lr_scheduler.ReduceLROnPlateau(optimizer, mode='max',
                                                   factor=opt.lr_decay_gamma,
                                                   patience=opt.lr_decay_patience)
    else:
        return NotImplementedError('learning rate policy [%s] is not implemented', opt.lr_policy)
    return scheduler


def init_weights(net, init_type='normal', gain=0.02):
    def init_func(m):
        classname = m.__class__.__name__
        if hasattr(m, 'weight') and (classname.find('Conv') != -1 or classname.find('Linear') != -1):
            if init_type == 'normal':
                init.normal_(m.weight.data, 0.0, gain)
            elif init_type == 'xavier':
                init.xavier_normal_(m.weight.data, gain=gain)
            elif init_type == 'kaiming':
                init.kaiming_normal_(m.weight.data, a=0, mode='fan_in')
            elif init_type == 'orthogonal':
                init.orthogonal_(m.weight.data, gain=gain)
            elif init_type == 'mean_space':
                batchsize, channel, height, weight = list(m.weight.data.size())
                m.weight.data.fill_(1 / (height * weight))
            elif init_type == 'mean_channel':
                batchsize, channel, height, weight = list(m.weight.data.size())
                m.weight.data.fill_(1 / (channel))
            else:
                raise NotImplementedError('initialization method [%s] is not implemented' % init_type)
            if hasattr(m, 'bias') and m.bias is not None:
                init.constant_(m.bias.data, 0.0)
        elif classname.find('BatchNorm2d') != -1:
            init.normal_(m.weight.data, 1.0, gain)
            init.constant_(m.bias.data, 0.0)

    print('initialize network with %s' % init_type)
    net.apply(init_func)


def init_net(net, init_type='normal', init_gain=0.02, gpu_ids=[]):
    if len(gpu_ids) > 0:
        assert (torch.cuda.is_available())
        net.to(gpu_ids[0])
        net = torch.nn.DataParallel(net, gpu_ids)
    init_weights(net, init_type, gain=init_gain)
    return net


class SumToOneLoss(nn.Module):
    def __init__(self):
        super(SumToOneLoss, self).__init__()
        self.register_buffer('one', torch.tensor(1, dtype=torch.float))

        self.loss = nn.L1Loss(size_average=False)

    def get_target_tensor(self, input):
        target_tensor = self.one
        return target_tensor.expand_as(input)

    def __call__(self, input):
        input = torch.sum(input, 1)
        target_tensor = self.get_target_tensor(input)
        # print(input[0,:,:])
        loss = self.loss(input, target_tensor)
        # loss = torch.sum(torch.abs(target_tensor - input))
        return loss


def kl_divergence(p, q):
    p = F.softmax(p)
    q = F.softmax(q)

    s1 = torch.sum(p * torch.log(p / q))
    s2 = torch.sum((1 - p) * torch.log((1 - p) / (1 - q)))
    return s1 + s2


class SparseKLloss(nn.Module):
    def __init__(self):
        super(SparseKLloss, self).__init__()
        self.register_buffer('zero', torch.tensor(0.01, dtype=torch.float))

    def __call__(self, input):
        input = torch.sum(input, 0, keepdim=True)
        target_zero = self.zero.expand_as(input)
        loss = kl_divergence(target_zero, input)
        return loss


class ResBlock(nn.Module):
    def __init__(self, input_ch):
        super(ResBlock, self).__init__()
        self.net = nn.Sequential(
            nn.Conv2d(input_ch, input_ch, 1, 1, 0),
            nn.LeakyReLU(0.2, True),
            nn.Conv2d(input_ch, input_ch, 1, 1, 0)
        )

    def forward(self, x):
        out = self.net(x)
        return out + x


def define_msi2s(input_ch, output_ch, gpu_ids, n_res, init_type='kaiming', init_gain=0.02, useSoftmax=True):
    # net = Msi2Delta(input_c=input_ch, output_c=output_ch, ngf=64, n_res=n_res, useSoftmax=useSoftmax)
    net =Msi2Delta(input_c=input_ch, output_c=output_ch,kernel_size=3, block_num=3,ngf=30, useSoftmax=useSoftmax)

    # net = Msi2Delta(in_channels=input_ch, out_channels=output_ch,kernel_size=3, stride=1, batch_norm=False, activation=None )

    return init_net(net, init_type, init_gain, gpu_ids)


# 下面就是借鉴了denseblock的写法
# Msidelta其实就是denseblock
class Msi2Delta(nn.Module):
    # 本身就是默认的
    def __init__(self, input_c, output_c,block_num, ngf=30, n_res=3, useSoftmax=True, scaling_factor=2, kernel_size=3,act=nn.ReLU,n_resblocks=4,res_groups=2,reduction=16):
        super(Msi2Delta, self).__init__()
        self.block_num = block_num
        layer = []


        # Initial Convolution Layer

        self.init_conv = nn.Conv2d(input_c, ngf * 2, 1, 1, 0)

        # Dense Blocks
        self.block1 = nn.Sequential(
            nn.Conv2d(ngf*2 , ngf *4,  5,1,padding=(5// 2) * 3,dilation=3),
            nn.LeakyReLU(0.2, True),
            nn.Conv2d(ngf * 4, ngf *4, 7,1,padding=(7 // 2) * 4,dilation=4),
            nn.LeakyReLU(0.2, True),
            nn.BatchNorm2d(ngf *4)
        )
        self.block2 = nn.Sequential(
            nn.Conv2d(ngf*4 + ngf * 2, ngf *8,  5,1,padding=(5 // 2) * 3,dilation=3),
            nn.LeakyReLU(0.2, True),
            nn.Conv2d(ngf *8, ngf *8,  7,1,padding=(7 // 2) * 4,dilation=4),
            nn.LeakyReLU(0.2, True),
            nn.BatchNorm2d(ngf *8)
        )

        # Final Convolution Layer
        self.final_conv = nn.Conv2d(ngf * 8 + ngf * 4 + ngf*2 , output_c, 1, 1, 0)
        # self.conv = nn.Conv2d(in_channels=input_c, out_channels=output_c * (scaling_factor ** 2),
        #                       kernel_size=kernel_size, padding=kernel_size // 2)

        self.atten_c = ChannelAttentionBlock(channel=output_c, reduction=4)
        self.softmax = nn.Softmax(dim=1)
        self.usefostmax = useSoftmax

    def forward(self, x):
        # print(x.shape)
        # Initial Convolution Layer
        out = self.init_conv(x)
        # Dense Blocks
        out_block1 = self.block1(out)
        # 第二个卷积的部分等于第一个卷积的部分相加
        out_block2 = self.block2(torch.cat((out_block1, out), dim=1))
        # 然后这是第二个连接块
        out = torch.cat((out_block2, out_block1, out), dim=1)
        # 因为最后的卷积部分是直接把所有的相加了，所以这里是final_conv
        # Final Convolution Layer
        out = self.final_conv(out)
        # print(self.usefostmax)
        # apply channel attention
        out_c = self.atten_c(out)
        # out_n =self.atten(out)
        # out_d = self.atten_d(out)
        # print(out_c.shape)
        # out_s = self.atten_s(out_c)
        if self.usefostmax == True:
            return self.softmax(out_c)
        elif self.usefostmax == False:
            return out_c







def define_s2img(input_ch, output_ch, gpu_ids, init_type='kaiming', init_gain=0.02):
    net = S2Img(input_c=input_ch, output_c=output_ch)

    return init_net(net, init_type, init_gain, gpu_ids)


class S2Img(nn.Module):
    def __init__(self, input_c, output_c):
        super(S2Img, self).__init__()

        self.net = nn.Sequential(
            nn.Conv2d(input_c, output_c, 1, 1, 0, bias=False),
            nn.ReLU()
        )

        # print('input_c, output_c',input_c, output_c)

    def forward(self, x):
        return self.net(x)

# from .block import ResidualGroup, default_conv as conv, MultiscaleFeatureExtractBlock

def define_lr2s(input_ch, output_ch, gpu_ids,block_num=5,growth_rate=32, init_type='kaiming', init_gain=0.02, useSoftmax=True):
    net = Lr2Delta(input_c=input_ch, output_c=output_ch, block_num=block_num,growth_rate=growth_rate,ngf=30,useSoftmax=useSoftmax)

    # net = TransferNetwork()
    # net = Lr2Delta(in_channels=input_ch, out_channels=output_ch,kernel_size=3, stride=1, batch_norm=False, activation=None )
    return init_net(net, init_type, init_gain, gpu_ids)

from .attention import CBAM


    # 多路径学习
class Lr2Delta(nn.Module):
    def __init__(self, input_c, output_c,block_num,growth_rate, ngf=30, n_res=3, useSoftmax=True):
        super(Lr2Delta, self).__init__()
        self.block_num = block_num
        layer = []
        self.left_path=nn.Sequential(nn.Conv2d(input_c,ngf*2, 9,1,padding=(9 // 2) * 5,dilation=5),
                                     nn.BatchNorm2d(ngf*2),
                                     nn.LeakyReLU(0.2, True),
                                     *[ResidualBlock(ngf*2,) for _ in range(block_num)],#ResidualBlock
                                     nn.BatchNorm2d(ngf*2),
                                     nn.LeakyReLU(0.2, True),
                                     nn.Conv2d(ngf *2, ngf * 4, 7,1,padding=(7 // 2) * 4,dilation=4),
                                     nn.BatchNorm2d(ngf * 4),
                                     # nn.ReLU()
                                     nn.LeakyReLU(0.2, True),
                                     )
        self.mid_path=nn.Sequential(nn.Conv2d(input_c,ngf*2, 9,1,padding=(9 // 2) * 5,dilation=5),
                                    nn.BatchNorm2d(ngf*2),
                                    nn.LeakyReLU(0.2, True),
                                     *[ResidualBlock(ngf*2) for _ in range(block_num)],
                                    nn.BatchNorm2d(ngf*2),
                                    nn.LeakyReLU(0.2, True),
                                     # nn.Conv2d(ngf*2,ngf*4, 7,1,padding=(7 // 2) * 4,dilation=4),
                                     # nn.BatchNorm2d(ngf * 4),
                                     # nn.LeakyReLU(0.2,True),
                                    nn.Conv2d(ngf *2, ngf * 4,7,1,padding=(7 // 2) * 4,dilation=4),
                                    nn.BatchNorm2d(ngf *4),
                                    # nn.ReLU()
                                    nn.LeakyReLU(0.2, True),

                                    )
        self.right_path = nn.Sequential(nn.Conv2d(input_c, ngf*2, 9,1,padding=(9 // 2) * 5,dilation=5),
                                        nn.BatchNorm2d(ngf*2),
                                        nn.LeakyReLU(0.2, True),
                                      *[ResidualBlock(ngf*2) for _ in range(block_num)],
                                        nn.BatchNorm2d(ngf*2),
                                        nn.LeakyReLU(0.2, True),
                                      nn.Conv2d(ngf*2, ngf*4, 7,1,padding=(7 // 2) * 4,dilation=4),
                                      nn.BatchNorm2d(ngf *4),
                                      nn.LeakyReLU(0.2,True),
                                      # nn.Conv2d(ngf * 4, ngf * 8, 5, 1, padding=(5 // 2) * 3, dilation=3),
                                      # nn.BatchNorm2d(ngf * 8),
                                      #   # nn.ReLU()
                                      # nn.LeakyReLU(0.2, True),
                                      )
        self.adjust = nn.Sequential(
            nn.Conv2d(ngf * 12, output_c, 3,1,1),
            # nn.ReLU()
        )

        self.usesoftmax = useSoftmax
        # self.usesoftmax = useSoftmax
        self.atten_n=NonLocalAttention(channel=output_c)
        self.atten =CBAM(channel=output_c)
        self.atten_CA = SEAttention(channel=output_c, reduction=16)
        self.atten_s =SpatialAttentionBlock(channel=output_c)

        self.softmax = nn.Softmax(dim=1)

        self.usesoftmax=useSoftmax

    def forward(self,x):
        lp = self.left_path(x)
        mp = self.mid_path(x)
        rp = self.right_path(x)
        fusionFeature = self.adjust(torch.cat((lp, mp, rp), 1))
        # out=self.atten_n(fusionFeature)
        out = self.atten_s(fusionFeature)

        if self.usesoftmax == True:
            return self.softmax(out)
        elif  self.usesoftmax ==False:
            return out



def define_psf(scale, gpu_ids, init_type='mean_space', init_gain=0.02):
    net = PSF(scale=scale)
    return init_net(net, init_type, init_gain, gpu_ids)


class PSF(nn.Module):
    def __init__(self, scale):
        super(PSF, self).__init__()
        self.net = nn.Conv2d(1, 1, scale, scale, 0, bias=False)
        self.bn = nn.BatchNorm2d(1)
        self.scale = scale

        self.softmax = nn.Softmax(dim=1)

        self.relu = nn.ReLU(inplace=True)
        # 初始化权重
        #nn.init.xavier_uniform_(self.net.weight)

    def forward(self, x):
        batch, channel, height, weight = list(x.size())
        out = torch.cat([self.net(x[:, i, :, :].view(batch, 1, height, weight)) for i in range(channel)], 1)
        # out = self.bn(out)
        # out = F.relu(out + x)  # 添加残差连接
        return nn.ReLU()(out)

def define_hr2msi(args, hsi_channels, msi_channels, sp_matrix, sp_range, gpu_ids, init_type='mean_channel',
                  init_gain=0.02):
    if args.isCalSP == False:
        net = matrix_dot_hr2msi(sp_matrix)
    elif args.isCalSP == True:
        net = convolution_hr2msi(hsi_channels, msi_channels, sp_range)

    return init_net(net, init_type, init_gain, gpu_ids)


class convolution_hr2msi(nn.Module):
    def __init__(self, hsi_channels, msi_channels, sp_range):
        super(convolution_hr2msi, self).__init__()

        self.sp_range = sp_range.astype(int)
        self.length_of_each_band = self.sp_range[:, 1] - self.sp_range[:, 0] + 1
        self.length_of_each_band = self.length_of_each_band.tolist()
        # import ipdb
        # ipdb.set_trace()
        self.conv2d_list = nn.ModuleList([nn.Conv2d(x, 1, 1, 1, 0, bias=False) for x in self.length_of_each_band])
        # self.scale_factor_net = nn.Conv2d(1,1,1,1,0,bias=False)

    def forward(self, input):
        # batch,channel,height,weight = list(input.size())
        # scaled_intput = torch.cat([self.scale_factor_net(input[:,i,:,:].view(batch,1,height,weight)) for i in range(channel)], 1)
        scaled_intput = input
        cat_list = []
        for i, layer in enumerate(self.conv2d_list):
            input_slice = scaled_intput[:, self.sp_range[i, 0]:self.sp_range[i, 1] + 1, :, :]
            out = layer(input_slice).div_(layer.weight.data.sum(dim=1).view(1))
            cat_list.append(out)
        return torch.cat(cat_list, 1).clamp_(0, 1)


class matrix_dot_hr2msi(nn.Module):
    def __init__(self, spectral_response_matrix):
        super(matrix_dot_hr2msi, self).__init__()
        self.register_buffer('sp_matrix', torch.tensor(spectral_response_matrix.transpose(1, 0)).float())

    def __call__(self, x):
        batch, channel_hsi, heigth, width = list(x.size())
        channel_msi_sp, channel_hsi_sp = list(self.sp_matrix.size())
        hmsi = torch.bmm(self.sp_matrix.expand(batch, -1, -1),
                         torch.reshape(x, (batch, channel_hsi, heigth * width))).view(batch, channel_msi_sp, heigth,
                                                                                      width)
        return hmsi


class NormGANLoss(nn.Module):
    def __init__(self, target_real_label=1.0, target_fake_label=0.0):
        super(NormGANLoss, self).__init__()
        self.register_buffer('real_label', torch.tensor(target_real_label))
        self.register_buffer('fake_label', torch.tensor(target_fake_label))
        self.loss = nn.L1Loss(size_average=False)

    def get_target_tensor(self, input, target_is_real):
        if target_is_real:
            target_tensor = self.real_label
        else:
            target_tensor = self.fake_label
        return target_tensor.expand_as(input)

    def __call__(self, input, target_is_real):
        target_tensor = self.get_target_tensor(input, target_is_real)
        return self.loss(input, target_tensor)


class NonZeroClipper(object):

    def __call__(self, module):
        # filter the variables to get the ones you want
        if hasattr(module, 'weight'):
            w = module.weight.data
            w.clamp_(0, 1e8)


class ZeroOneClipper(object):

    def __call__(self, module):
        # filter the variables to get the ones you want
        if hasattr(module, 'weight'):
            w = module.weight.data
            w.clamp_(0, 1)


class SumToOneClipper(object):

    def __call__(self, module):
        if hasattr(module, 'weight'):
            if module.in_channels != 1:
                w = module.weight.data
                w.clamp_(0, 10)
                w.div_(w.sum(dim=1, keepdim=True))
            elif module.in_channels == 1:
                w = module.weight.data
                w.clamp_(0, 5)


#   Channel Attention Block
class ChannelAttentionBlock(nn.Module):
    def __init__(self, channel, reduction=4):
        super(ChannelAttentionBlock, self).__init__()
        self.reduction = reduction
        self.dct_layer = nn.AdaptiveAvgPool2d(1)  # DCTLayer(channel)
        self.fc = nn.Sequential(
            nn.Linear(channel, channel // reduction, bias=False),
            nn.ReLU(inplace=True),
            nn.Linear(channel // reduction, channel, bias=False),
            nn.Sigmoid()
        )

    def forward(self, x):
        n, c, h, w = x.size()
        y = self.dct_layer(x).squeeze(-1).squeeze(-1)
        y = self.fc(y).view(n, c, 1, 1)
        return x * y.expand_as(x)


#   Spatial Attention Block
class SpatialAttentionBlock(nn.Module):
    def __init__(self, channel):
        super(SpatialAttentionBlock, self).__init__()

        # Maximum pooling
        self.featureMap_max = nn.Sequential(
            nn.ReflectionPad2d(2),
            nn.MaxPool2d(kernel_size=(5, 5), stride=(1, 1), padding=0)
        )
        # Average pooling
        self.featureMap_avg = nn.Sequential(
            nn.ReflectionPad2d(2),
            nn.AvgPool2d(kernel_size=(5, 5), stride=(1, 1), padding=0)
        )

        # Deviation pooling
        # var = \sqrt(featureMap - featureMap_avg)^2

        # Dimensionality Reduction
        self.reduce_dim = nn.Sequential(
            nn.Conv2d(in_channels=channel * 4, out_channels=channel, kernel_size=(3, 3), stride=(1, 1), padding=1,
                      bias=False),
            nn.Conv2d(in_channels=channel, out_channels=channel, kernel_size=(1, 1), stride=(1, 1), bias=False),
            nn.Sigmoid()
        )

    def forward(self, x):
        x_max = self.featureMap_max(x)
        x_avg = self.featureMap_avg(x)
        x_var = torch.sqrt(torch.pow(x - x_avg, 2) + 1e-7)

        y = torch.cat([x_max, x_avg, x_var, x], dim=1)
        z = self.reduce_dim(y)
        return x * z
class spectral_res_block(nn.Module):
    def __init__(self, input_channel,shrink_factor=0.1):  # input_channel 60
        super().__init__()
        self.one = nn.Sequential(
            nn.Conv2d(in_channels=input_channel, out_channels=int(input_channel / 3), kernel_size=1, stride=1),
            nn.ReLU(),
            nn.Conv2d(in_channels=int(input_channel / 3), out_channels=input_channel, kernel_size=1, stride=1)
        )
        self.shrink_factor = shrink_factor
    def forward(self, input):
        identity_data = input
        output = self.one(input) # 60
        output = output*self.shrink_factor
        output = torch.add(output, identity_data)  # 60
        output = nn.ReLU()(output)  # 60
        return output


class ResidualBlock(nn.Module):
    def  __init__(self,input_c,output_c=60,ngf=30, stride=1,shortcut=True):
        super(ResidualBlock, self).__init__()
        self.block1=nn.Sequential(nn.Conv2d(input_c,ngf*4,5,1,padding=(5 // 2) * 3,dilation=3),
                                  nn.BatchNorm2d(ngf*4),
                                  nn.ReLU(inplace=True),
                                  nn.Conv2d(ngf*4,ngf*8,7,1,padding=(7 // 2) * 4,dilation=4),
                                  nn.BatchNorm2d(ngf*8),
                                  nn.ReLU(inplace=True),
                                  nn.Conv2d(ngf*8,output_c, 9,1,padding=(9 // 2) * 5,dilation=5),
                                  nn.BatchNorm2d(output_c))

        self.shortcut = shortcut
        self.block2=nn.Sequential(nn.Conv2d(input_c,output_c,3,stride,1),
                                  nn.BatchNorm2d(output_c),)

        self.relu=nn.ReLU(inplace=True)
    def forward(self,input):
        x=input
        out=self.block1(x)
        if self.shortcut:
            out=x+out
            return out
        else:
            out =out+self.block2(x)
            out=self.relu(out)
            return out
class residuaigroup(nn.Module):
    def __init__(self,input_c,output_c=60,ngf=30,shortcut=True):
        super(residuaigroup, self).__init__()
        self.left_path=nn.Sequential(
                                     nn.Conv2d(input_c,ngf, 5,1,padding=(5 // 2) * 3,dilation=3),
                                     nn.BatchNorm2d(ngf),
                                     # nn.LeakyReLU(0.2, True),
                                     nn.ReLU(inplace=True),
                                     nn.Conv2d(ngf, ngf*2, 7,1,padding=(7 // 2) * 4,dilation=4),
                                     nn.BatchNorm2d(ngf*2),
                                     nn.ReLU(inplace=True),
                                    nn.Conv2d(ngf*2, ngf * 3, 9,1,padding=(9 // 2) * 5,dilation=5),
                                    nn.BatchNorm2d(ngf * 3),
                                    nn.ReLU(inplace=True)

                                    )
        self.mid_path=nn.Sequential(
                                    nn.Conv2d(input_c, ngf,  5,1,padding=(5 // 2) * 3,dilation=3),
                                    nn.BatchNorm2d(ngf),
                                    # nn.LeakyReLU(0.2, True),
                                    nn.ReLU(inplace=True),
                                    nn.Conv2d(ngf, ngf * 2,  7,1,padding=(7 // 2) * 4,dilation=4),
                                    nn.BatchNorm2d(ngf * 2),
                                    nn.ReLU(inplace=True),
                                    nn.Conv2d(ngf * 2, ngf * 3,  9,1,padding=(9 // 2) * 5,dilation=5),
                                    nn.BatchNorm2d(ngf * 3),
                                    nn.ReLU(inplace=True)
                                     )
        self.right_path=nn.Sequential(
                                    nn.Conv2d(input_c, ngf, 5,1,padding=(5 // 2) * 3,dilation=3),
                                    nn.BatchNorm2d(ngf),
                                    # nn.LeakyReLU(0.2, True),
                                    nn.ReLU(inplace=True),
                                    nn.Conv2d(ngf, ngf * 2,  7,1,padding=(7 // 2) * 4,dilation=4),
                                    nn.BatchNorm2d(ngf * 2),
                                    nn.ReLU(inplace=True),
                                    nn.Conv2d(ngf * 2, ngf * 3,  9,1,padding=(9 // 2) * 5,dilation=5),
                                    nn.BatchNorm2d(ngf * 3),
                                    nn.ReLU(inplace=True)
                                    )
        self.adjust = nn.Sequential(
            nn.Conv2d(ngf*9, output_c,3,1,1),
            # nn.BatchNorm2d(output_c),
            nn.ReLU())
        self.shortcut = shortcut
        self.block2 = nn.Sequential(nn.Conv2d(input_c, output_c, 3, 1, 1),
                                    nn.BatchNorm2d(output_c), )

        self.relu = nn.ReLU(inplace=True)
        self.atten_c=ChannelAttentionBlock(channel=output_c)
    def forward(self,input):
        x=input
        lp = self.left_path(x)
        mp = self.mid_path(x)
        rp = self.right_path(x)
        fusionFeature = self.adjust(torch.cat((lp, mp, rp), 1))
        y=self.atten_c(fusionFeature)
        if self.shortcut:
            out=y+x
            return out
        else:
            out=y+self.block2(x)
            return out

class residualnet(nn.Module):
    def __init__(self,input_c,output_c=60,ngf=30,shortcut=True):
        super(residualnet, self).__init__()
        self.layer1 = nn.Sequential(nn.Conv2d(input_c, ngf, 9,1,padding=(9 // 2) * 5,dilation=5),
                                    nn.BatchNorm2d(ngf),
                                    nn.ReLU(inplace=True)
                                    # nn.LeakyReLU(0.2, True)
                                    )
        self.layer2 = nn.Sequential(nn.Conv2d(ngf, ngf*2, 7,1,padding=(7 // 2) * 4,dilation=4),
                                    nn.BatchNorm2d(ngf*2),
                                    nn.ReLU(inplace=True)
                                    # nn.LeakyReLU(0.2, True)
                                    )
        self.layer3 = nn.Sequential(nn.Conv2d(ngf*2, ngf*4, 5,1,padding=(5 // 2) * 3,dilation=3),
                                    nn.BatchNorm2d(ngf*4),
                                    nn.ReLU(inplace=True)
                                    # nn.LeakyReLU(0.2, True)
                                    )
        self.layer4 = nn.Sequential(nn.Conv2d(ngf*4, ngf*8, 3,1,padding=(3 // 2) * 2,dilation=2),
                                    nn.BatchNorm2d(ngf*8),
                                    nn.ReLU(inplace=True)
                                    # nn.LeakyReLU(0.2, True)
                                    )
        self.adjust = nn.Sequential(
            nn.Conv2d(ngf*15, output_c, 7,1,3),
            nn.ReLU()
        )
        self.shortcut=shortcut
        self.block2 = nn.Sequential(nn.Conv2d(input_c, output_c, 3, 1, 1),
                                    nn.BatchNorm2d(output_c), )

        self.relu = nn.ReLU(inplace=True)
        self.atten_c=ChannelAttentionBlock(channel=output_c,reduction=4)
        self.atten_n=SpatialAttentionBlock(channel=output_c)
        self.atten=NonLocalAttention(channel=output_c)


    def forward(self, input):
        x=input
        l1 = self.layer1(x)
        l2 = self.layer2(l1)
        l3 = self.layer3(l2)
        l4 = self.layer4(l3)
        res = torch.cat((l1, l2, l3, l4), 1)
        out = self.adjust(res)
        out_c=self.atten(out)

        if self.shortcut:
            out_n = out + x
            return out_n
        else:
            out_n = out+ self.block2(x)
            return out_n























