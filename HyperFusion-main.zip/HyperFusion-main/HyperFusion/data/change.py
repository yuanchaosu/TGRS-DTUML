import scipy.io as sio
import skimage.io
imgpath = r'E:\envi转换成matlab格式\envi转换成matlab格式\envi转换成matlab格式\Houston\Houston.tif'
imggt = skimage.io.imread(imgpath)
sio.savemat(r"E:\envi转换成matlab格式\envi转换成matlab格式\envi转换成matlab格式\Houston\Houston.mat", {'imggt': imggt})
